import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      title: "Render with Sufficient Contrast",
      
      home: Home()
      )
  );
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     


  body: Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text("Would you like to close the app?"),

        MaterialButton(
          color: Colors.green,
          onPressed: (){
          },
          child: Text("Yes"),),

        MaterialButton(
          
          color: Colors.red,
          onPressed: (){
          },
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
            Icon(Icons.do_not_disturb_on, color: Colors.white),
            Text("No", style: TextStyle(color: Colors.white))
          ],),)



      ],),
   
   /* TextScaleFactor
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text("Some text"),
        Text("Some sample text", textScaleFactor: 2.0),
    ],)
*/





/*Good Contrast Button
child: MaterialButton(
        color: Colors.blue,
        child: Text("Hello", 
        //style: TextStyle(color: Colors.green[200]),
        ),
        onPressed: (){
          debugPrint("Button Pressed");
        },
      )
*/


/*Bad Contrast Button

      child: MaterialButton(
        color: Colors.blue[200],
        child: Text("Hello", style: TextStyle(color: Colors.blue[100]),),
        onPressed: (){
          debugPrint("Button Pressed");
        },
      )
    
  */
  
  ),
    );
  }
}