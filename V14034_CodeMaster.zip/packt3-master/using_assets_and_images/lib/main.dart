import 'package:flutter/material.dart';
import './ui/my_first_widget.dart';





void main(){
  runApp(
    MaterialApp(
      title: "How to Create a Widget",
      home: Home()
    )
  );
}

  var assetsImage = new AssetImage('images/cat.jpg');
  String imageUrl = 'https://picsum.photos/250?image=9';
  
  



class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    

    return Scaffold(
      appBar: AppBar(
        title: Text("How to Create a Widget"),
        backgroundColor: Colors.purple,
      ),

    body: Center(
      
      child: Column(
        children: <Widget>[
          SizedBox(height: 20.0,),
          Image(image: assetsImage, width: 200.0, height: 160.0),
          Text('Image Asset', 
          style: TextStyle(fontFamily: 'IndieFlower', fontWeight: FontWeight.w800),),

          SizedBox(height: 20.0,),
          Image.network(imageUrl, width: 200.0, height: 160),
          Text('Network Asset', 
          style: TextStyle(fontFamily: 'IndieFlower', fontWeight: FontWeight.w800),),
        ],
      )),

      floatingActionButton: MyFirstWidget(
        onPressed: ()=> debugPrint("Button Tapped")
      ),



    );
  }
}