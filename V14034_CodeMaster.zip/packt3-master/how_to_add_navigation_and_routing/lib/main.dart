import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      title: "How to Add Navigation and Routing",
      //home: StartScreen(),              //comment this line when using routes
      routes: {
        '/': (context)=>StartScreen(),
        '/second': (context)=>NextScreen(),
        '/last': (context)=>LastScreen(),
      },
      )
    );
}

class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('First Screen'),
        ),


        body: Center(
          child: RaisedButton(
            child: Text("Go to Screen 2"),
            onPressed: (){
              Navigator.push(
                context,
            MaterialPageRoute(builder: (context) => NextScreen()),
  );

            },),
        ),
      
    );
  }
}


class NextScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Second Screen'),
        ),


        body: Center(
          
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RaisedButton(
                child: Text("Go to Screen 1"),
                onPressed: (){
                  Navigator.pop(context);
                },),

              RaisedButton(
                child: Text("Go to Screen 3"),
                onPressed: (){
                  Navigator.push(
                context,
            MaterialPageRoute(builder: (context) => LastScreen()),
  );
                },),




            ],
          ),
        ),
      
    );
  }
}

class LastScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Last Screen'),
        automaticallyImplyLeading: false,     //remove ugly back button step 2
        ),


        body: Center(
          child: RaisedButton(
            child: Text("Go to Screen 1"),
            onPressed: (){
              //Empty the navigator stack and remove all routes
              Navigator.of(context)
              .pushNamedAndRemoveUntil('/', (Route<dynamic> route) => false);
            },),
        ),
      
    );
  }
}