// Imports the Flutter Driver API.
import 'package:flutter_driver/flutter_driver.dart';
import 'package:test/test.dart';

void main(){
group('Quiz App', () {

//Create SeralizableFinders to locate specific widgets
    final scoreTextFinder = find.byValueKey('score');
    final choice1ButtonFinder = find.byValueKey('choice1Button');
    final choice1ButtonTextFinder = find.byValueKey('choice1ButtonText');
    

//Create a Flutter driver object and store it in a variable driver
    FlutterDriver driver;

//Connect to the Flutter driver before running any tests.
    setUpAll(() async {
      driver = await FlutterDriver.connect();
    });


//Disconnect from the app in the teardownAll() function after the tests complete    
    tearDownAll(() async {
      if (driver != null) {
        driver.close();
      }
    });

//Test the important scenarios
test('score begins at 0... will increase if answer is right', () async{
  //Verify the score starts at 0
  expect(await driver.getText(scoreTextFinder), "Score: 0");
});

test('change text from cat to tiger',() async{
  await driver.tap(choice1ButtonFinder);
  expect(await driver.getText(choice1ButtonTextFinder), "A. tiger");
});



  });
}