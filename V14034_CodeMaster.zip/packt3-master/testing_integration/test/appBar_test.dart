import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main(){
  Widget createWidgetForTesting({Widget child}){
    return MaterialApp(home: child);
  }

  testWidgets('Creating an appBar to test', (WidgetTester tester) async {
      Widget appBar = AppBar(title: Text("Plant Quiz"));

      await tester.pumpWidget(createWidgetForTesting(child: appBar));

      //Create a Finder
      final titleFinder = find.text('Animal Quiz');
      expect(titleFinder, findsOneWidget);

  });



}


