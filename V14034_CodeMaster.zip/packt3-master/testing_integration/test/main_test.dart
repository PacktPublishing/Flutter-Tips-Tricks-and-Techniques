import 'package:flutter_test/flutter_test.dart';
import 'package:testing/main.dart';

void main(){
  test('A message is displayed after answering a question', (){
      final quizMessage = QuizMessage();

      var message1 = quizMessage.correctAnswer();
      var message2 = quizMessage.wrongAnswer();

      expect(message1, "Right");
      expect(message2, "Wrong");
  });
}
 