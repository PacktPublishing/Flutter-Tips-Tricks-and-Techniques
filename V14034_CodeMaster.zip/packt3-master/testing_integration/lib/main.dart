import 'package:flutter/material.dart';
import 'dart:convert';

void main(){

  runApp(
    MaterialApp(
      title: "Testing",
      home: Home()
    )
  );
}
    int questionNumber = 0;
    int score = 0;
    int numberOfQuestions;
    var quizData;

    

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {

    var media = MediaQuery.of(context).size;
 
    return Theme(
      data: ThemeData(
        textTheme: TextTheme(
          body1: media.width>375?
          TextStyle(fontSize: 32.0):
          TextStyle(fontSize: 18.0),

          button: media.width>375?
          TextStyle(fontSize: 32.0):
          TextStyle(fontSize: 18.0),
          
      )),

      child: FutureBuilder(
        future: DefaultAssetBundle.of(context).loadString('lib/data/quiz1.json'),
        builder: (BuildContext context, AsyncSnapshot snapshot){

          if(snapshot.hasData){
            quizData = json.decode(snapshot.data.toString());
            return Scaffold(
             appBar: AppBar(
               title: Text("Animal Quiz")),

              body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Expanded(
              child: Container(
                color: Colors.white,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[

                    SizedBox(height: 45.0,),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[                  
                          Text("Question ${questionNumber + 1} of ${quizData.length}"),
                          Text("Score: $score", key: Key('score'),)                 
                        ],
                        ),
                    ),

                    Expanded(child: Image(
                      image: AssetImage('images/${quizData[questionNumber]['image']}.jpg')                     
                      )),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text("${quizData[questionNumber]['question']}"),
                      
                    ),
                  ],),
                ),
            ),

            Expanded(
              child: Container(
                color: Colors.grey.shade100,
                child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[

                    RaisedButton(
                      key: Key('choice1Button'),                      
                      onPressed: (){
                       updateQuestion("choice1");                              
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(                          
                          "A. ${quizData[questionNumber]['choice1']}",
                          key: Key('choice1ButtonText')),
                      )),

                    RaisedButton(
                      onPressed: (){
                       updateQuestion("choice2"); 
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          "B. ${quizData[questionNumber]['choice2']}"),
                      )),

                  ],),


                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[

                    RaisedButton(
                      onPressed: (){
                       updateQuestion("choice3");
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          "C. ${quizData[questionNumber]['choice3']}"),
                      )),

                    RaisedButton(
                      onPressed: (){
                        updateQuestion("choice4");
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Text(
                          "D. ${quizData[questionNumber]['choice4']}"),
                      )),

                  ],)

                ],),
                ),
            )
          ])

            );
          }else {
            return Container();
          }
          
        },
    ));
  }

  updateQuestion(String choice){
    debugPrint("${questionNumber + 2}/${quizData.length}");
    if(quizData[questionNumber][choice] == quizData[questionNumber]['answer']){
      score++;
      QuizMessage().correctAnswer();
    //debugPrint("Right");
      }else{
        QuizMessage().wrongAnswer();
      }
    setState(() {
      if (questionNumber + 1 == quizData.length){
        debugPrint("End of Quiz");
      }else{
        questionNumber++;
      }
      
    });
  }

}


//Called on Line 167 & 170
class QuizMessage{

  String correctAnswer(){
    return "Right";
  }

  String wrongAnswer(){
    return "Wrong";
  }

}