import 'package:flutter/material.dart';
import 'package:flutter_sequence_animation/flutter_sequence_animation.dart';
import 'dart:async';


void main(){
  runApp(MaterialApp(
    title: "Staggered Animations",
    home: SequenceAnimationExample()));
}

class SequenceAnimationExample extends StatefulWidget {
  @override
  _SequenceAnimationExampleState createState() => _SequenceAnimationExampleState();
}

class _SequenceAnimationExampleState extends State<SequenceAnimationExample> with SingleTickerProviderStateMixin {

  AnimationController controller;
  SequenceAnimation sequenceAnimation;

@override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this);
    //initialize the sequence animation
    sequenceAnimation = SequenceAnimationBuilder()
    .addAnimatable(
      animatable: ColorTween(begin: Colors.blue, end: Colors.green),
      from: Duration(milliseconds: 0),
      to: Duration(milliseconds: 1500),
      tag: "color",
    ).addAnimatable(
      animatable: new Tween<double>(begin: 50.0, end: 300.0),
      from:  const Duration(seconds: 0),
      to: const Duration(seconds: 3),
      tag: "height",
      curve: Curves.ease
    ).addAnimatable(
      animatable: new Tween<double>(begin: 50.0, end: 200.0),
      from: const Duration(seconds: 0),
      to: const Duration(seconds: 3),
      tag: "width",
      curve: Curves.ease
    ).addAnimatable(
      animatable: ColorTween(begin: Colors.green, end: Colors.yellow),
      from: Duration(milliseconds: 1500),
      to: Duration(milliseconds: 3000),
      tag: "color",
    ).animate(controller);
    
  }

  Future<Null> playAnimation() async {
    try {
      await controller.forward().orCancel;
      await controller.reverse().orCancel;
    } on TickerCanceled {
      // the animation got canceled, probably because we were disposed
    }
}




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Sequence Animation"),
      ),

      body: GestureDetector(
            onTap: (){
              playAnimation();
            },
              child: Container(
          padding: const EdgeInsets.all(32.0),
          child: Center(
            child: AnimatedBuilder(
              animation: controller,
              builder: (BuildContext context, Widget child){
                return Container(
                  height: sequenceAnimation['height'].value,
                  width: sequenceAnimation['width'].value,
                  color: sequenceAnimation['color'].value,
                );
              },),),
        ),
      ),
    );
  }
}