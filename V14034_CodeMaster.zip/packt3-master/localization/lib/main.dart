import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import './app_localizations.dart';

void main(){
  runApp(
    MaterialApp(
      title:"Greeting",
      home: Greeting(),

      supportedLocales: [
        Locale('en', 'US'),
        Locale('fr', 'CA')
      ],

      localizationsDelegates: [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate
      ],

      localeResolutionCallback: (locale, supportedLocales){
        for(var supportedLocale in supportedLocales){
          if(supportedLocale.languageCode == locale.languageCode && 
          supportedLocale.countryCode == locale.countryCode){
            return supportedLocale;
          }
        }

        return supportedLocales.first;
      },
    )
  );
}

class Greeting extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(child: Text(
       AppLocalizations.of(context).translate('greeting'),
       style: TextStyle(fontSize: 24.0), 
      ),)
      
    );
  }
}