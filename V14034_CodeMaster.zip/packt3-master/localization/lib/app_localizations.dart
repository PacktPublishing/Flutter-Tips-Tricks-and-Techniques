import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppLocalizations{
  //Create a final field
  final Locale locale;

  //Add a contructor
  AppLocalizations(this.locale);


  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

//this static member will allow us to access this class from material app
  static const LocalizationsDelegate<AppLocalizations> delegate =
  _AppLocalizationsDelegate();

  //declare a map of type sting to string
   Map<String, String> _localizedValues;

   Future<bool> load() async{

    //Convert json data to a string
     String jsonString = await rootBundle.loadString('languages/${locale.languageCode}.json');
     Map<String, dynamic> jsonMap = json.decode(jsonString);

     _localizedValues = jsonMap.map((key, value){
       return MapEntry(key, value.toString());
     });

     return true;
   } 

  //Takes a key as parameter and searches localized values for the translation
   String translate(String key){
     return _localizedValues[key];
   }
}

//AppLocalizationsDelegate class should be private
//LocalizationsDelegate is a factory for a set of localized resources
//We are bridging the flutter SDK with the AppLocalizations class we just created

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations>{

  //This takes a constant constructor  because this instance doesn't change
  const _AppLocalizationsDelegate();

  
  //we need to override is supported
  @override
  bool isSupported(Locale locale) {
    return ['en', 'fr'].contains(locale.languageCode);
  }

  @override
  Future<AppLocalizations> load(Locale locale) async{
    
    AppLocalizations localizations = AppLocalizations(locale);
    await localizations.load();
    return localizations;
  }

  @override
  bool shouldReload(LocalizationsDelegate<AppLocalizations> old)=> false;


}