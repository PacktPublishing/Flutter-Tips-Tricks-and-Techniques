# Flutter Tips, Tricks and Techniques

## 1.2 - How to Use Hot Reload
## 1.3 - How to Run the App on a Physical Device
## 1.4 - How to Use Code Formatting
## 1.5 - How to Develop Packages and Plugins

## 2.1 - How to Create a Widget
## 2.2 - Using Assets and Images
## 2.3 - How to Add Navigation and Routing
## 2.4 - Using Hero Animations
## 2.5 - Using Staggered Animations via Sequence Animation Package

## 3.1 - How to Adjust Text for Phones and Tablets
## 3.2 - How to Adapt Screens for Portrait and Landscape
## 3.3 - Tips on Building Apps for People with Visual Impairments
## 3.4 - How to Translate Your App to Another Language
## 3.5 - How to Use the Camera

## 4.1 - How to Debug Mobile Apps
## 4.2 - Using an OEM Debugger
## 4.3 - How to Use Flutter's Build Modes
## 4.4 - How to Test the App with Unit Testing and Widget Testing
## 4.5 - How to Test the App with Integration Testing


## 5.1 - How to use Flavors in Flutter
## 5.2 - How to Prepare an Android App for Release
## 5.3 - How to Prepare an IOS App for Release
## 5.4 - How to Setup Continuous Deployment with Flutter on Android with Fastlane
## 5.5 - How to Setup Continuous Deployment with Flutter on iOS with Fastlane