import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';


void main(){

//This is a helper method and it provides functionality to make the login page testable
  Widget createWidgetForTesting({Widget child}){
return MaterialApp(
  home: child,
);
}


  testWidgets('Creating an appBar to test', (WidgetTester tester) async {

      Widget appBar = AppBar(title: Text("Animal Quiz"));

      await tester.pumpWidget(createWidgetForTesting(child: appBar));
  });
}