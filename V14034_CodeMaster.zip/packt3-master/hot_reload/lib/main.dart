import 'package:flutter/material.dart';
String initialText="Bye";


void main(){

  runApp(
    MaterialApp(
      home: Home()
      )
  );
}

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  @override
  void initState() {
    super.initState();
     setTextToHello();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow,
      body: Center(child: Text(
        initialText, 
        style: TextStyle(
          fontSize: 24.0
          ))),

      


    );
  }
String setTextToHello(){
  setState(() {
    initialText = "Hello World";
  });
}

}