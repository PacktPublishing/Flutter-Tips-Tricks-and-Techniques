import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      title: "Debugging Apps",
      home: Home()
    )
  );
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Container(
          height: 407.0,
          width: 400.0,
          color: Colors.blue),

        Container(
          height: 406.0,
          width: 400.0,
          color: Colors.yellow),

      ],
    );
  }
}