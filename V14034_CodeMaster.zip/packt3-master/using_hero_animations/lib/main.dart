import 'package:flutter/material.dart';

void main(){
  runApp(
    MaterialApp(
      title: "Using Hero Animations",
      home: Home()
    )
  );
}

var assetsImage = new AssetImage('images/dog.jpg');

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Using Hero Animations"),
        ),

        body:Column(
          
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Hero(
            tag: 'image',
            child: GestureDetector(
              child: Image(image: assetsImage, width: 80.0, height: 60.0),
              onTap:(){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context)=>HeroWidgetExample()));
              }
              )      
            )
          ]),

    );
  }
}

class HeroWidgetExample extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hero Widget"),),
      
      body: Center(
        child: Hero(
          tag: 'image',
          child: Image(image: assetsImage, width: 280.0, height: 200.0),
        ),
      ),

    );
  }
}