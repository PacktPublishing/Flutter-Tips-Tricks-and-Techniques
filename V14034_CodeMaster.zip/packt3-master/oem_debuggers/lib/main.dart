import 'package:flutter/material.dart';

void main(){

  runApp(
    MaterialApp(
      title: "OEM Debugging",
      home: Home()
    )
  );
}


class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

int _counter = 0;
void _incrementCounter(){
  setState((){
    _counter++;
  });
}

void _decrementCounter(){
  setState((){
    _counter--;

  });
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body:Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[

          Expanded(
              child: Container(
                child: Center(
                  child: Text("$_counter", style: TextStyle(fontSize: 60.0) ,),),
                color: Colors.blue,
              )),

          Expanded(
              child: Container(
                color: Colors.yellow,
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[

                          RaisedButton(
                          color: Colors.white,
                          elevation: 4.0, 
                          child: Text("+", style: TextStyle(fontSize: 24.0),),
                          onPressed: (){
                            _incrementCounter();
                            debugPrint("$_counter");
                          }),
                          
                          SizedBox(width: 5.0),

                          RaisedButton(
                          color: Colors.white,
                          elevation: 4.0,  
                          child: Text("-", style: TextStyle(fontSize: 24.0),),
                          onPressed: (){
                             _decrementCounter();
                            debugPrint("$_counter");
                            debugPrint("1st line: Debugger is working");
                            debugPrint("2nd line: Debugger is working");
                            debugPrint("3rd line: Debugger is working");
                            debugPrint("4th line: Debugger is working");
                            debugPrint("5th line: Debugger is working");


                          }),



                    ],
                  ),
                )
              )),

        ],
      )

    );
  }
}




