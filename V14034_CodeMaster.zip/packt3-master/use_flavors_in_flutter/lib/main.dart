import 'package:flutter/material.dart';
import 'resources/app_config.dart';

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.of(context).appTitle,
      home:Scaffold(
        appBar: AppBar(
          title: Text(AppConfig.of(context).buildFlavor)),
          
          body: Center(child: Text(AppConfig.of(context).buildFlavor)),
          
          
          
          
          ),
    );
  }
}