import 'package:flutter/material.dart';
import 'resources/app_config.dart';
import 'main.dart';

void main(){
  return runApp(
    AppConfig(
      appTitle: "How to Use Flavours in Flutter",
      buildFlavor: "Production",
      child: Home()
      )
  );
}