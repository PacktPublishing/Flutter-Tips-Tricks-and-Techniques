import 'package:flutter/material.dart';



void main(){
  
  runApp(
    MaterialApp(
      title: "Responsive Layouts",
      home: ResponsiveLayout(),
      )
  );
}

class ResponsiveLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    
    var media = MediaQuery.of(context).size;

    return Theme(
      data: ThemeData(
        textTheme: TextTheme(
          body1: media.width>375?
          TextStyle(fontSize: 32.0):
          TextStyle(fontSize: 14.0)
          
          )),
          child: Scaffold(

        appBar: AppBar(
          title: Text("Responsive Layouts"),
        ),

        //Part 1

        // body: Center(
        //   child: Column(
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     children: <Widget>[
        //       Text(
        //         "${media.width}",
        //         style: media.width > 375?
        //         TextStyle(fontSize: 25.0):
        //         TextStyle(fontSize: 12.0)
        //         ),
        //     ],
        //   ),),

        //Part 2

        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "${media.width}"
              )
            ],),
        ),

      


  

      ),
    );
  }
}

