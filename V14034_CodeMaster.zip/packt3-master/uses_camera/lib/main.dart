import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:camera/camera.dart';


Future<void> main()async{
  final cameras = await availableCameras();
  final firstCamera = cameras.first;

  runApp(MaterialApp(home:CameraApp(
    camera: firstCamera,
  )));
}

class CameraApp extends StatefulWidget {
    final CameraDescription camera;

    const CameraApp({Key key, @required this.camera}):super(key: key);


  @override
  _CameraAppState createState() => _CameraAppState();
}

class _CameraAppState extends State<CameraApp> {
  CameraController _controller;
  Future<void> _initializeControllerFuture;

  @override
  void initState() {
    super.initState();
    _controller = CameraController(widget.camera, ResolutionPreset.medium);
    _initializeControllerFuture = _controller.initialize();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Camera App')),

      body: FutureBuilder<void>(
        future: _initializeControllerFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            // If the Future is complete, display the preview.
            return CameraPreview(_controller);
          } else {
            // Otherwise, display a loading indicator.
            return Center(child: CircularProgressIndicator());
          }
        },
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.camera_alt),
        onPressed: ()async{
          try{
            await _initializeControllerFuture;
            final path = join(
                //first part of the string
                (await getTemporaryDirectory()).path,
                //second part of the string
                '${DateTime.now()}.png'   
            );

            print(path);
            await _controller.takePicture(path); 


          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => Gallery(imagePath: path,))
          );



          }catch (e){
            print(e);
          }
        },),
      
    );
  }
}


class Gallery extends StatelessWidget {
  final String imagePath;

  const Gallery({Key key, this.imagePath}):super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    appBar: AppBar(title: Text("Gallery"),),  
      body: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Image.file(File(imagePath), width: 300.0,height: 300.0,),
      ],
    ));
  }
}