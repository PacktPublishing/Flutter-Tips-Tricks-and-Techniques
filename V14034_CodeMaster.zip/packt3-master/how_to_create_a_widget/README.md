# 2_1_how_to_create_a_widget

In this project we create a custom widget from basic widgets.




